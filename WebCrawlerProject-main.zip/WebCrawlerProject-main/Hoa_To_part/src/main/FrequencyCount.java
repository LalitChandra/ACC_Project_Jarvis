package main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringTokenizer;

public class FrequencyCount {
public static void frqcount() {
		String currentDir = System.getProperty("user.dir");
		String textLocation = currentDir +"\\W3C Web Pages\\";
		File[] textFiles =  new File(textLocation).listFiles();
		
		StringBuilder contentBuilder = new StringBuilder();
		//File Reading
		for(File f: textFiles)
		{
			try {
			    BufferedReader in = new BufferedReader(new FileReader(f));
			    String str;
			    while ((str = in.readLine()) != null) {
			        contentBuilder.append(str);
			    }
			    in.close();
			} catch (IOException e) {
				System.out.println("Unable to read file");
			}
		}
		
		// Converting file content to string
		String content = contentBuilder.toString();
		StringTokenizer st = new StringTokenizer(content," ");
	
		Hashtable<String, Integer> frequencyTable = new Hashtable<String, Integer>(); // java default hashtable
		String word;
		//iterating the string words
	     while (st.hasMoreTokens()) {
	    	 word = st.nextToken();
	    	 if(word != null && word.matches("^[a-zA-Z0-9]*$")) {
	    		 word = word.toLowerCase(); // case ignoring
	    		 if (frequencyTable.containsKey(word)) {
	    		        frequencyTable.put(word, frequencyTable.get(word) + 1); // increasing word counter if already present in hash table
	    		    } else {
	    		        frequencyTable.put(word, 1);
	    		    }
	    	 }
	     }
	     Set<Entry<String, Integer>> itr = frequencyTable.entrySet();
	     for(Map.Entry<String, Integer> entry: itr)
	     {
	    	 System.out.println(entry.getKey()+": "+entry.getValue());
	     }

	}
public static void main(String[] args) 
{
	frqcount();
}
}
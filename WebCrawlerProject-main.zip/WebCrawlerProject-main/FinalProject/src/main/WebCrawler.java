package main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WebCrawler 
{
	 
	// initialize MAX_DEPTH variable with final value  
	private static final int MAX_PAGES = 20;
	
	// create set that will store links  
	private HashSet<String> urlLinks;
	public static int numPage =0; 
	
	// initialize set using constructor  
	public WebCrawler() 
	{   
		urlLinks = new HashSet<>();   
	}  
	
	public void crawl(String URL) throws IOException
	{
		urlLinks.add(URL);
		Document document = Jsoup.connect(URL).get();
		
		String patternCrawl = "^(https?)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*(\\.)(ca|com)[-a-zA-Z0-9+&@#/%=~_|]*";
        Pattern pattern = Pattern.compile(patternCrawl);
        Elements pageLinks= document.select("a[href]");
        String url;
        long duplicateURL=0, notMatch=0;
        for(Element currentPage : pageLinks)
        {
        	if (numPage > MAX_PAGES) break;
            url = currentPage.attr("abs:href");
            //System.out.println(url);
            Matcher matcher = pattern.matcher(url);
            if(urlLinks.contains(url))
            {
                System.out.println(url+ " | URL previously visited");
                duplicateURL++;
            }
            //else if(!patternCrawl.matches(url))//change this if it does not work
            else if (!matcher.find())
            //else if(!Pattern.matches(patternCrawl,url))
            {
            	//System.out.println("break"+matcher.find());
                System.out.println(url+ " | URL does not matched the pattern requirement");
                notMatch++;
            }
            else
            {
                urlLinks.add(currentPage.attr("abs:href"));
                System.out.println(url+ " | URL will be crawled");
                numPage++;
            }
        }
        System.out.println("Number of duplicate URLs : "+duplicateURL);
        System.out.println("Number of invalid URLs : "+notMatch);
        System.out.println("Number of unique URLs : "+urlLinks.size());
	}
	public static void saveHtmlAsText() throws IOException 
	{
		
	}
	// main() method start  
		
	public static void main(String[] args) 	
	{   
		// create instance of the WebCrawlerExampleWithDepth class  
		WebCrawler obj = new WebCrawler();  
		
		try {
			obj.crawl("https://www.bestbuy.ca/en-ca");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  
}
	
	    

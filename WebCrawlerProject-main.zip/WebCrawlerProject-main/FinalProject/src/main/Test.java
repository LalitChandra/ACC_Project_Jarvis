package main;

public class Test 
{
	public static void main(String[] args) 
	{
		WebCrawler obj = new WebCrawler();
		
		
	}
}

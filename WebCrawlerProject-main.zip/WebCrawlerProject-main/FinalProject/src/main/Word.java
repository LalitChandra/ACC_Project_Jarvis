package main;

public class Word 
{
	int frequency;
	String word;
	
	public Word(String value)
	{
		frequency = 1;
		String word = value;
	}
}

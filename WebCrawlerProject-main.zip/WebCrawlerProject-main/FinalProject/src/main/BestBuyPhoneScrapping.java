package main;

public class BestBuyPhoneScrapping 
{
	// Best buy html element that stores the product list
	private static final String PRODUCT_LIST_ITEM = "col-xs-12_198le col-sm-4_13E9O col-lg-3_ECF8k x-productListItem productLine_2N9kG";
	
	// Best buy html element that contains product name
	private static final String PRODUCT_NAMES = "div.productItemName_3IZ3c";
	
	// Best buy html element that stores pricing-related information
	private static final String PRODUCT_PRICES = "div.productPricingContainer_3gTS3";
	
	// Best buy html element that contains the product's price
	private static final String PRODUCT_INDIVIDUAL_PRICE = "span[data-automation=product-price] > div";
	
	private static void checkProduct(Product p)
	{
		if(p.name.contains("Monthly"))
			p.setPaymentType("Monthly - 24 months");
		else
			p.setPaymentType("Unlocked - One time pay");
	}
	
	
	
	public static void main(String[] args) 
	{
		
	}
}
